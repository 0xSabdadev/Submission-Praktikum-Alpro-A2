/*Nama File 	: KalkSS.c*/
/*Deskripsi 	: menghitung dan menampilkan harga barang setelah diberikan diskon berdasarkan inputan jenis barang j dan harga barang h*/
/*Pembuat   	: 24060121130045-Farhan Adka Reynaldi*/
/*Tgl Pembuatan	: 17-03-2022*/
#include <stdio.h> /*header file*/
#include <stdlib.h>

/*Program Utama*/
int main()
{ /*Kamus*/
  int h; /*harga barang*/
  char j; /*jenis barang A-C*/

  /*Algoritma*/
  printf("Masukkan harga barang:");
  scanf("%d",&h);
  printf("Masukkan jenis barang A-C:");
  scanf("%c",&j);
  switch (j)
  {
      case 'A' :
            printf("%d",h*0.9);/*diskon 10%*/
            break;
      case 'B' :
            printf("%d",h*0.85);/*diskon 15%*/
            break;
      case 'C':
            printf("%d",h*0.8);/*diskon 20%*/
            break;
      default:
            printf("Masukkan jenis barang salah");
  }
  return 0;
}
