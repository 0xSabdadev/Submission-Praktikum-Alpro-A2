/*Nama File 	: KalkSS.c*/
/*Deskripsi 	: menerima dua input bilangan integer dan menghitung proses perhitungan sesuai inputan karakter (a, b, c, d, e, dan f)*/
/*Pembuat   	: 24060121130045-Farhan Adka Reynaldi*/
/*Tgl Pembuatan	: 17-03-2022*/

#include <stdio.h> /*header file*/
#include <stdlib.h>

/*Program Utama*/
int main()
{ /*Kamus*/
  int iA, iB;
  char o;

  /*Algoritma*/
  printf("Masukkan bilangan pertama:");
  scanf("%d",&iA);
  printf("Masukkan bilangan kedua:");
  scanf("%d",&iB);
  printf("Masukkan operasi a - f : ");
  scanf(" %c",&o);
  switch (o)
  {
      case 'a' :
            printf("%d",iA + iB);
            break;
      case 'b' :
            printf("%d",iA - iB);
            break;
      case 'c':
            printf("%d",iA * iB);
            break;
      case 'd':
            printf("%f",(float)iA / (float)iB);
            break;
      case 'e':
            printf("%d",iA / iB);
            break;
      case 'f':
            printf("%d",iA % iB);
            break;
      default:
            printf("Bukan pilihan menu yang benar");
  }
  return 0;
}
